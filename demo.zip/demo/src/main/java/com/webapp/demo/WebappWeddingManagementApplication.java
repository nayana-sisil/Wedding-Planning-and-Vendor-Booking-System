package com.webapp.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebappWeddingManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebappWeddingManagementApplication.class, args);
	}

}
